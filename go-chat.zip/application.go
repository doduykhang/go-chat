package main

import "net/http"

func main() {
	http.HandleFunc("/", HelloHandler)
	http.ListenAndServe(":5000", nil)
}

func HelloHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Hello world"))	
}
